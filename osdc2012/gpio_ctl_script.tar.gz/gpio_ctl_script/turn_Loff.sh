#!/bin/bash
#Program:
#	Control gpio_137 status to output low
#History
#20120215	Gavin first release
#

folder=/sys/class/gpio

ctl=low

if [ ! -d $folder/gpio137 ];then
	echo 137 > $folder/export

fi

echo $ctl > $folder/gpio137/direction

