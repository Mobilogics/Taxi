#!/bin/bash
#Program:
#	Control gpio_138 status to output high,then turn low
#History
#20120215	Gavin first release
#

folder=/sys/class/gpio

ctl=high

if [ ! -d $folder/gpio138 ];then
	echo 138 > $folder/export

fi

echo $ctl > $folder/gpio138/direction
sleep 1
ctl=low
echo $ctl > $folder/gpio138/direction

