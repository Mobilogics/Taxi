#!/bin/bash
#Program:
#	Control gpio_136 status to output high
#History
#20120215	Gavin first release
#

folder=/sys/class/gpio

ctl=high

if [ ! -d $folder/gpio136 ];then
	echo 136 > $folder/export
fi

#if [ `cat $folder/gpio136/value` == 1 ] && [ `cat $folder/gpio137/value` == 1 ];then
#	echo 0 > $folder/gpio137/value
#	exit 0
#fi

echo $ctl > $folder/gpio136/direction

