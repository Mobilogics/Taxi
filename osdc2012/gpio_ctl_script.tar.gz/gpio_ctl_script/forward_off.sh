#!/bin/bash
#Program:
#	Control gpio_136,137 status to output low
#History
#20120215	Gavin first release
#

folder=/sys/class/gpio

ctl=low

if [ ! -d $folder/gpio136 ];then
	echo 136 > $folder/export
fi

if [ ! -d $folder/gpio137 ];then
	echo 137 > $folder/export
fi


echo $ctl > $folder/gpio136/direction ; echo $ctl > $folder/gpio137/direction

